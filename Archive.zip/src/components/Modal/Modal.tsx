import React from 'react';
import './modal.css'

interface IModalProps {
   setShowModal: (arg: boolean) => void;
   modalTitle: string;
   modalMessage: string;
   buttonContent: string;
}

const Modal: React.FC<IModalProps> = ({
   setShowModal,
   modalTitle,
   modalMessage,
   buttonContent,
}) => {
   const closeModal = () => setShowModal(false);
   
   return (
         <div className='modal'
         // style={{
         //    width: '100%', 
         //    height:' 100%', 
         //    background: 'rgba(0,0,0,0.8)',
         //    position: 'fixed',
         //    display: 'flex',
         //    justifyContent: 'center',
         //    alignItems: 'center',
         //    zIndex: 3
         //}}
            onClick={closeModal}>
            <div className='modal-background'
            // style={{
            //    borderRadius: '20px',
            //    width: '500px',
            //    height: '300px',
            //    boxShadow: '0 5px 16px rgba(0,0,0,0.2)',
            //    background: '#fff',
            //    padding: '2rem 0',
            //    position: 'fixed',
            //    display: 'flex',
            //    flexDirection: 'column',
            //    justifyContent: 'center',
            //    alignItems: 'center',
            //    zIndex: 10,
            //    transform: 'translate(-50%, -50%)'
            // }}
            >
               <div className='modal-wrapper'
               // style={{
               //    display: 'flex',
               //    flexDirection: 'column',
               //    justifyContent: 'center',
               //    alignItems: 'center',
               //    lineHeight: 2,
               //    color: '#343E7A',
               //    margin:' 1rem'
               // }}
               >
                  <h2>{modalTitle}</h2>
                  <p 
                  // style={{marginBottom: '1rem'}}
                  >{modalMessage}</p>
                  <button 
                  // style={{
                  //    margin: '0.5rem',
                  //    padding: '10px 24px',
                  //    background: '#343E7A',
                  //    color: '#fff',
                  //    border: 'none',
                  //    borderRadius: '10px'
                  // }}
                  onClick={closeModal}>{buttonContent}</button>
               </div>
            </div>
         </div>
   );
};

export default Modal;
